# -*- coding: utf-8 -*-
"""
Created on Mon Apr  19 19:19 2021

@author: Mohammad Mahdi Banasaz 
"""

from setuptools import setup

setup (
       name='StVAR',
       version='0.0.4',
       describtion='Students t Vector AutoRegression',
       py_moudles=["StVAR"],
       package_dir={'': 'src'},
       )
