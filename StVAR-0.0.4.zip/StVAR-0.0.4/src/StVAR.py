# -*- coding: utf-8 -*-
"""
Created on Fri Jan 15 12:59:12 2021
version 0.0.2 + AR Fiendly + Scaled/Orthogonal t
@author: Mohammad Mahdi Banasaz
"""

# AR friendly and MS testing modified
# Distribution: Student's t
# Dependence: Markov(l)
# Homogeneity: Stationarity + mean trending

### on progress (red dots)
# conditioanl varince function scaler
# standard error from hess_inv
# Scaled/Orthogonal t 


# %% import required modules
# instal: !pip install numdifftools


import sklearn.datasets
import statsmodels.api as sm
import sklearn as sk
import scipy 
import numpy as np
import pandas as pd
import math
import statistics as stats
import matplotlib.pyplot as plt
import seaborn as sb
from numpy import size, log, pi, sum, diff, array, zeros, diag, mat, asarray, sqrt, copy, random
from numpy.linalg import inv
import scipy.optimize as optimize
from scipy.optimize import fmin_slsqp, fmin_bfgs, minimize, show_options, BFGS
from scipy.stats import skew, kurtosis
import scipy.linalg as la
from tabulate import tabulate
import timeit
import datetime
import statsmodels.api as sm
from matplotlib import pyplot as plt
import scipy.stats 
from collections import OrderedDict
import sys
import time
import warnings #Ignores the warnings in the module. Specifically for the optimization determinant...
import sympy as sym
import yfinance as yf
warnings.filterwarnings('ignore')
#random.seed(12345) #Change this line for different random numbers!



### Functions ###

# %% Scaled t
def scaled_t(data):
    n = size(data,0)
    t_scaled = []
    
    for t in range(1,n+1):
        t_s = (2*t - n - 1)/(n-1)
        t_scaled.append(t_s)
                   
    return t_scaled


# %% Chebyshev Polynomial of the First Kind
def Chebyshev_poly(t_s, trend): #Where t_s is the scaled time variable and trend is the order of the trend. Note trend > 0
    t = sym.symbols('t')
    namespace = globals()
    
    orthogonal_trend = pd.DataFrame()
    for k in range(trend+1):
        constant = ((-1)**k*2**k*math.factorial(k))/(math.factorial(2*k))
        w = (1 - t**2)**(0.5)
        der = (1 - t**2)**(k-0.5)
        ddt = sym.diff(der,t,k) 
        poly = sym.expand(constant*w*ddt)
    
        f = sym.lambdify(t,poly)
    
        namespace['t_%d' %(k)] = []
        
        for i in range(0, size(t_s,0)):
            namespace['t_%d' %(k)].append(f(t_s[i]))
            
        orthogonal_trend['t_%d' %(k)] = namespace['t_%d' %(k)]
            
    return orthogonal_trend
# Chebyshev_poly(scaled_t(data), trend)    
       
# %% Chebyshev Polynomial of the Second Kind           
def Chebyshev_poly_2(t_s, trend): #Where t_s is the scaled time variable and trend is the order of the trend. Note trend > 0
    t = sym.symbols('t')
    namespace = globals()
    
    orthogonal_trend = pd.DataFrame()
    for k in range(trend+1):
        constant = ((-1)**k*2**k*math.factorial(k+1))/(math.factorial(2*k+1))
        w = (1 - t**2)**(-0.5)
        der = (1 - t**2)**(k+0.5)
        ddt = sym.diff(der,t,k) 
        poly = sym.expand(constant*w*ddt)
    
        f = sym.lambdify(t,poly)
    
        namespace['t_%d' %(k)] = []
        
        for i in range(0, size(t_s,0)):
            namespace['t_%d' %(k)].append(f(t_s[i]))
            
        orthogonal_trend['t_%d' %(k)] = namespace['t_%d' %(k)]
    
    return orthogonal_trend

    ## Notes on Scaled and Chebyshev Trend Polynomials (see Michaelides and Spanos (2020) for more information)
        #In order to account for t-heterogeneity, we use determininstic trend polynomials. 
        #However, it is common to run into near-collinearity issues when fitting trend polynomials using least squares.
        #To reduce the near-collinearity problem, we can use a scaled time variable in conjunction with orthogonal polynomials 
        #Here, we use the scaled time variable and Chebyshev Orthogonal Polynomials of the First Kind
        #Orthogonal polynomials are unneccessary for trend terms where three is the highest power

# Chebyshev_poly_2(scaled_t(data), trend)     
      
# %% t student simulation
def Multivariate_St_rvs(mean, var, df, n):
    '''generate random variables of multivariate t distribution
    Parameters
    ----------
    mean : array_like
        mean of random variable, length determines dimension of random variable
    var : array_like
        square array of covariance  matrix
    df : int or float
        degrees of freedom
    n : int
        number of observations, return random array will be (n, len(m))
    Returns
    -------
    rvs : ndarray, (n, len(m))
        each row is an independent draw of a multivariate t distributed
        random variable
    '''    
    mean = np.asarray(mean)
    d = len(mean)
    if df == np.inf:
        x = 1.
    else:
        x = np.random.chisquare(df, n)/df
    z = np.random.multivariate_normal(np.zeros(d),var,(n,))
    return mean + z/np.sqrt(x)[:,None]

#%% data simulation

def Simulation_St(mean, df, n=100, trend=False, graph=False): # mean is a list of means  e.x. [0.9, 0.7, 2, 5], trend = [0.02, 0.03, 0.04]
    var = sklearn.datasets.make_spd_matrix(size(mean), random_state=None) #Generate random 4x4 symmetric, positive-definite matrix
    sim = pd.DataFrame(Multivariate_St_rvs(mean, var, df, n))
    
    if trend == False:
        if graph != False:
            for i in range (size(mean)):
                fig, ax = plt.subplots(figsize=(20, 10))
                ax.plot(sim.iloc[:,i], color='r')
                plt.show()
        
        return sim
        
           
    else: 
        sim_trend = pd.DataFrame(zeros((size(sim,0), size(sim,1))))

        
        for i in range(size(sim,1)):
            for t in range(size(sim,0)):
                sim_trend.iloc[t,i] = sim.iloc[t,i]
                for j in range (size(trend)):
                    sim_trend.iloc[t,i] = sim_trend.iloc[t,i] + trend[j]*(t+1)**(j+1) 
        if graph != False:
            for i in range (size(mean)):
                fig, ax = plt.subplots(figsize=(20, 10))
                ax.plot(sim_trend.iloc[:,i], color='r')
                plt.show()
        
        return sim_trend
        


# sim_trend = Simulation_St([0.9, 0.7, 2, 5], 4, n=100, trend=[0.2], graph=True)    

    
#%% Simulation test


def Simulation_test(mean, df, n=100, trend=0, lag=2, draw=1000, scaled = False, cheby = False, graph=True):
    
    start = time.time()

    for d in range (draw):
        print("number of draw: ",d)
    
        ## data_sim
        data_sim = Simulation_St(mean, df, n)
        
        ## Starting Values
        starting_vals = Starting_values(data_sim, trend, lag)

        ##optimization    
        estimates_slsqp = fmin_slsqp(Neg_St_VAR_likelihood, starting_vals, args = (data_sim, df, trend, lag, scaled, cheby), iter=100,\
                                     acc=1e-06, iprint=2, full_output=True, epsilon=1.4901161193847656e-8 )

        loglik, logliks, M, SIGMA = St_VAR_likelihood(estimates_slsqp[0], data_sim, df, trend, lag, scaled, cheby, out= True)
        
        if d == 0:
            M_sim = M[0:4].flatten()
            SIGMA_sim = SIGMA[0:4, 0:4].flatten()
        else:
            M_sim = np.vstack((M_sim, M[0:4].flatten()))
            SIGMA_sim = np.vstack((SIGMA_sim, SIGMA[0:4, 0:4].flatten()))
    
    end = time.time()
    print((end-start)/60, "minutes to run the optimazation")   # last time 17.5 hours

    if graph == True:

        for i in range (M_sim.shape[1]):
            plt.hist(M_sim[:,i], bins='auto', color='#0504aa', alpha=0.7)
            plt.title("M_sim"+ str(i+1))
            plt.show()
    
        for i in range (SIGMA_sim.shape[1]):
            plt.hist(SIGMA_sim[:,i], bins='auto', color='#0504aa', alpha=0.7)
            plt.title("S_sim"+ str(i+1))
            plt.show()    

    return M_sim, SIGMA_sim



# %% Function to Create Starting Values
def Starting_values(data, trend, lag, scaled = False, cheby = False, out = False):           
    
    k = size(data,1)   
    if trend == 0: 
        
        if scaled == True or cheby == True:
            sys.exit("Trend must be greater than or equal to zero for trend scaling or orthogonal trend polynomials to be relevant")
        elif scaled == False and cheby == False:
            #Mean
            mean_parameters = OrderedDict(("mu{0}".format(i), np.mean(data.iloc[:,i])) for i in range(k))
        
            M_ = [mean_parameters.get(key) for key in mean_parameters]
       
            #Variance        
            Cov_parameters = OrderedDict()
          
            for m in range (lag+1):
                for n in range (lag+1):
                    for i in range (k):
                        for j in range(k):
                            if (m == 0 and n == 0 and j >= i):
                                Cov_parameters["sy" + str(i+1) + str(m) + "y" + str(j+1) + str(n)] = np.cov(data.iloc[:,i].shift(m).iloc[n:], data.iloc[:,j].shift(n).iloc[n:])[0,1]
                            elif (m == 0 and n > 0):
                                Cov_parameters["sy" + str(i+1) + str(m) + "y" + str(j+1) + str(n)] = np.cov(data.iloc[:,i].shift(m).iloc[n:], data.iloc[:,j].shift(n).iloc[n:])[0,1]
          
            SIGMA_ = [Cov_parameters.get(key) for key in Cov_parameters]
              
            starting_vals = M_ + SIGMA_
                
            if out is False:
                return starting_vals
            else:
                return starting_vals, M_, SIGMA_
        
    elif trend > 0:
       #Trending Mean (using least square on beta_0 + beta_1*t + beta_2* t**2 + beta_3* t**3)
       
       namespace = globals()
       for i in range (k):
           y = np.array(data.iloc[:,i])
           t_col = np.zeros((size(data,0), trend+1))
           
           if scaled == True and cheby == False:
               sc_t = scaled_t(data) #Function for scaling t variable is called
               col = np.asarray(sc_t) #This includes the newly scaled t variable
               for t in range (trend+1):
                   t_col[:,t] = col**(t)
               
           elif scaled == True and cheby == True:
               sc_t = scaled_t(data) #Function for scaling t variable is called
               Chebyshev_poly(sc_t, trend) #Creates the Chebyshev polynomials for the scaled t variable       
               for t in range (trend+1):
                    t_col[:,t] = np.asarray(namespace['t_%d' %(t)]) #the column is now the value corresponding to the Chebyshev polynomial evaluated for scaled t
                  
           elif scaled == False and cheby == False:
               col = np.asarray(list(range(1, size(data,0)+1)))
               for t in range (trend+1):
                    t_col[:,t] = col**(t)
               
               
           X = t_col
           namespace['beta_%d' %(i)] = np.matmul( np.linalg.inv(np.matmul(X.transpose(), X)), np.matmul(X.transpose(), y))

       mean_parameters = OrderedDict()
       for i in range(k):
           mean_parameters["mu" + str(i+1)] = namespace['beta_%d' %(i)][0]
           for j in range(trend):
               mean_parameters["mu" + str(i+1) + str(j+1)] = namespace['beta_%d' %(i)][j+1]
  
       M_ = [mean_parameters.get(key) for key in mean_parameters]


       # Ordinary Mean
       # mean_parameters = OrderedDict()
       # for i in range(k):
       #      mean_parameters["mu" + str(i+1)] = np.mean(data.iloc[0,i])
       #      for j in range(trend):
       #          mean_parameters["mu" + str(i+1) + str(j+1)] = 0.00
  
       # M_ = [mean_parameters.get(key) for key in mean_parameters]
        
       
       #Variance        
       Cov_parameters = OrderedDict()
          
       for m in range (lag+1):
            for n in range (lag+1):
                for i in range (k):
                        for j in range(k):
                            if (m == 0 and n == 0 and j >= i):
                                Cov_parameters["sy" + str(i+1) + str(m) + "y" + str(j+1) + str(n)] = np.cov(data.iloc[:,i].shift(m).iloc[n:], data.iloc[:,j].shift(n).iloc[n:])[0,1]
                            elif (m == 0 and n > 0):
                                Cov_parameters["sy" + str(i+1) + str(m) + "y" + str(j+1) + str(n)] = np.cov(data.iloc[:,i].shift(m).iloc[n:], data.iloc[:,j].shift(n).iloc[n:])[0,1]
        
       SIGMA_ = [Cov_parameters.get(key) for key in Cov_parameters]
        
       starting_vals = M_ + SIGMA_
                
       if out is False:
            return starting_vals
       else:
            return starting_vals, M_, SIGMA_
    else:
        sys.exit("Trend must be greater than or equal to zero")        

# %% StVAR Likelihood Function (Objective Function for log likelihood Maximization)
# Stationarity + mean Trending
#parameters = starting_vals

def St_VAR_likelihood(parameters, data, v, trend, lag, scaled = False, cheby = False, out = False, Mt_all=False):
    T = size(data,0)
    k = size(data,1)
    pn = 0 #numerair for defining parameters in loop


    if trend == 0: #if no trend is specified
        if scaled == True or cheby == True:
            sys.exit("Trend must be greater than or equal to zero for scaling to be relevant")
        
        elif scaled == False and cheby == False:   
        ### Defining Parameters:        
            ##Means
            mean_parameters = OrderedDict()
            for i in range(k):
                mean_parameters["mu" + str(i+1)] = parameters[pn]
                pn = pn + 1
        
            ## Variance - Covariance
            Cov_parameters = OrderedDict()
            for m in range (lag+1):
                for n in range (lag+1):
                    for i in range (k):
                            for j in range(k):
                                if (m == 0 and n == 0 and j >= i):
                                    Cov_parameters["sy" + str(i+1) + str(m) + "y" + str(j+1) + str(n)] = parameters[pn]
                                    Cov_parameters["sy" + str(j+1) + str(m) + "y" + str(i+1) + str(n)] = Cov_parameters["sy" + str(i+1) + "0" + "y" + str(j+1) + "0"] #Var-Cov parameters symmetry restrictions
                                    pn = pn + 1 
                                elif (m == 0 and n > 0):
                                    Cov_parameters["sy" + str(i+1) + str(m) + "y" + str(j+1) + str(n)] = parameters[pn]
                                    pn = pn + 1
                                elif (m > 0 and n > m): 
                                    Cov_parameters["sy" + str(i+1) + str(m) + "y" + str(j+1) + str(n)] = Cov_parameters["sy" + str(i+1) + "0" + "y" + str(j+1) + str(n-m)] #Stationary restrictions
               
        ### Making Variance-Covariance Matrix of Parameters
            ##sub matrices:
            namespace = globals()
        
            #s00
            for i in range(k):
                namespace['s00_%d' %(i+1)] = []
                for j in range(k):
                    namespace['s00_%d' %(i+1)].append(Cov_parameters["sy" + str(i+1) + str(0) + "y" + str(j+1) + str(0)])
                    
            namespace['s00'] = namespace['s00_1']
            for i in range(1,k):
                namespace['s00'] = np.matrix(np.vstack((namespace['s00'], namespace['s00_%d' %(i+1)])))
        
            #upper diagonal s:
            for m in range (lag+1):
                    for n in range (lag+1):
                        if n > m:
                            for i in range(k):
                                namespace['s%d%d_%d' %(m, n, (i+1))] = []
                                for j in range(k):
                                    namespace['s%d%d_%d' %(m, n, (i+1))].append(Cov_parameters["sy" + str(i+1) + str(m) + "y" + str(j+1) + str(n)])
                            namespace['s%d%d' %(m, n)] = namespace['s%d%d_1' %(m, n)]        
                            for i in range(1,k):
                                namespace['s%d%d' %(m, n)] = np.matrix(np.vstack((namespace['s%d%d' %(m, n)], namespace['s%d%d_%d' %(m, n, (i+1))])))                      
         
            ###diagonal s - equal to s00:
            for i in range (1,lag+1):
                namespace['s%d%d' %(i, i)] = namespace['s00']
            
            ###lower diafonal s - transpose of upper diagonal s:
            for m in range (lag+1):
                for n in range (lag+1):
                    if n < m:
                        if k ==1:
                            namespace['s%d%d' %(m, n)] = namespace['s%d%d' %(n, m)]
                        else:  
                            namespace['s%d%d' %(m, n)] = np.matrix.transpose(namespace['s%d%d' %(n, m)])
                        
            
            ##Put together SIGMA MATRIX
            for m in range (lag+1):
                namespace['sigma_%d' %(m)] = namespace['s%d0' %(m)]
                for n in range (1, lag+1):
                    namespace['sigma_%d' %(m)] = np.hstack((namespace['sigma_%d' %(m)], namespace['s%d%d' %(m, n)]))
                
            sigma = namespace['sigma_%d' %(0)]
            for m in range (1, lag+1):
                sigma = np.vstack((sigma, namespace['sigma_%d' %(m)]))
            
            SIGMA = sigma
                       
            ## Mean MATRIX
            M = [mean_parameters.get(key) for l in range(lag+1) for key in mean_parameters]        
            M = np.matrix(M).transpose()
            
        #loglikelihood Function
            constant = log(math.gamma((v+(lag+1)*k)/2)) - log(math.gamma(v/2)) - 0.5*k*(lag+1)*log(math.pi*v)
            logliks = zeros(T-lag)
         
            for t in range(0,T-lag):
                eps = np.flipud(np.matrix(data.iloc[t:t+lag+1])).flatten().transpose() - M  # xt(4*1) - M(4*1)
                d = (1 + 1/v* np.matmul(np.matmul(eps.transpose(),np.linalg.inv(SIGMA)),eps))
                logliks[t] = constant - 0.5*log(np.linalg.det(SIGMA)) -0.5*(v + (lag+1)*k)*log(d[0,0]) 
            
            loglik = sum(logliks)
            
            if out is False:
                return loglik
            else:
                return loglik, logliks, M, SIGMA            
        
    
    elif trend > 0: #If there is a trend specified    
        mean_parameters = OrderedDict()
        for i in range(k):
            mean_parameters["mu" + str(i+1)] = parameters[pn]
            for j in range(trend):
                mean_parameters["mu" + str(i+1) + str(j+1)] = parameters[pn+j+1]
            pn = pn + trend + 1
                
        M = [mean_parameters.get(key) for key in mean_parameters]
        M = np.reshape(np.array(M), (k,np.int(trend+1)))
    
            
    
        ## Variance - Covariance
        Cov_parameters = OrderedDict()
        for m in range (lag+1):
            for n in range (lag+1):
                for i in range (k):
                        for j in range(k):
                            if (m == 0 and n == 0 and j >= i):
                                Cov_parameters["sy" + str(i+1) + str(m) + "y" + str(j+1) + str(n)] = parameters[pn]
                                Cov_parameters["sy" + str(j+1) + str(m) + "y" + str(i+1) + str(n)] = Cov_parameters["sy" + str(i+1) + "0" + "y" + str(j+1) + "0"] #Var-Cov parameters symmetry restrictions
                                pn = pn + 1 
                            elif (m == 0 and n > 0):
                                Cov_parameters["sy" + str(i+1) + str(m) + "y" + str(j+1) + str(n)] = parameters[pn]
                                pn = pn + 1
                            elif (m > 0 and n > m): 
                                Cov_parameters["sy" + str(i+1) + str(m) + "y" + str(j+1) + str(n)] = Cov_parameters["sy" + str(i+1) + "0" + "y" + str(j+1) + str(n-m)] #Stationary restrictions
        
    
    ### Making Variance-Covariance Matrix of Parameters
        ##sub matrices:
        namespace = globals()
    
        #s00
        for i in range(k):
            namespace['s00_%d' %(i+1)] = []
            for j in range(k):
                namespace['s00_%d' %(i+1)].append(Cov_parameters["sy" + str(i+1) + str(0) + "y" + str(j+1) + str(0)])
                
        namespace['s00'] = namespace['s00_1']
        for i in range(1,k):
            namespace['s00'] = np.matrix(np.vstack((namespace['s00'], namespace['s00_%d' %(i+1)])))
    
        #upper diagonal s:
        for m in range (lag+1):
                for n in range (lag+1):
                    if n > m:
                        for i in range(k):
                            namespace['s%d%d_%d' %(m, n, (i+1))] = []
                            for j in range(k):
                                namespace['s%d%d_%d' %(m, n, (i+1))].append(Cov_parameters["sy" + str(i+1) + str(m) + "y" + str(j+1) + str(n)])
                        namespace['s%d%d' %(m, n)] = namespace['s%d%d_1' %(m, n)]        
                        for i in range(1,k):
                            namespace['s%d%d' %(m, n)] = np.matrix(np.vstack((namespace['s%d%d' %(m, n)], namespace['s%d%d_%d' %(m, n, (i+1))])))                      
     
        ###diagonal s - equal to s00:
        for i in range (1,lag+1):
            namespace['s%d%d' %(i, i)] = namespace['s00']
        
        ###lower diafonal s - transpose of upper diagonal s:
        for m in range (lag+1):
            for n in range (lag+1):
                if n < m:
                    if k ==1:
                        namespace['s%d%d' %(m, n)] = namespace['s%d%d' %(n, m)]
                    else:  
                        namespace['s%d%d' %(m, n)] = np.matrix.transpose(namespace['s%d%d' %(n, m)])
     
         ##Put together SIGMA MATRIX
        for m in range (lag+1):
            namespace['sigma_%d' %(m)] = namespace['s%d0' %(m)]
            for n in range (1, lag+1):
                namespace['sigma_%d' %(m)] = np.hstack((namespace['sigma_%d' %(m)], namespace['s%d%d' %(m, n)]))
            
        sigma = namespace['sigma_%d' %(0)]
        for m in range (1, lag+1):
            sigma = np.vstack((sigma, namespace['sigma_%d' %(m)]))
        
        SIGMA = sigma
        
    ###Likelihood Function                    

        sc_t = scaled_t(data)
        Chebyshev_poly(sc_t,trend)  

        logliks = zeros(T - lag)
        for t in range(0, T - lag):
            
            # Mean matrix M(t) = M_0 + M_1 t + M_2 t^2
            if scaled == True and cheby == False: #The time variable is scaled in this case
                for i in range(lag+1):
                    namespace['tpoly_%d' %(i)] = [(sc_t[t+lag-i])**j for j in range(trend+1)] #Note: If you just want scaled t and no Chebyshev polynomial, replace t in this line with sc_t[t] (also omitted the +1)
                    namespace['tp_%d' %(i)] = np.reshape(np.array(namespace['tpoly_%d' %(i)]),(len(namespace['tpoly_%d' %(i)]),1))
                    namespace['Mtrend_%d' %(i)] = np.dot(M,namespace['tp_%d' %(i)])
        
            elif scaled == True and cheby == True: #The time variable is scaled in this case
                for i in range(lag+1):                    
                    namespace['Cheby_%d' %(i)] = []
                    for j in range(trend+1):
                        namespace['Cheby_%d' %(i)].append(namespace['t_%d' %(j)][t+lag-i]) #This updates for the Chebyshev polynomial. Note the +1 is omitted
                    
                    namespace['tCheby_%d' %(i)] = np.reshape(np.array(namespace['Cheby_%d' %(i)]),(len(namespace['Cheby_%d' %(i)]),1))
                    namespace['Mtrend_%d' %(i)] = np.dot(M,namespace['tCheby_%d' %(i)])
            
            elif scaled == False and cheby == False: #The time variable is scaled in this case
                for i in range(lag+1):
                    namespace['tpoly_%d' %(i)] = [(t + lag + 1 - i)**j for j in range(trend+1)]
                    namespace['tp_%d' %(i)] = np.reshape(np.array(namespace['tpoly_%d' %(i)]),(len(namespace['tpoly_%d' %(i)]),1))
                    namespace['Mtrend_%d' %(i)] = np.dot(M,namespace['tp_%d' %(i)])
                
            # Puting together
            Mtrend = namespace['Mtrend_%d' %(0)]
            for i in range(1, lag+1):
                Mtrend = np.vstack((Mtrend, namespace['Mtrend_%d' %(i)]))
                namespace['Mt_%d' %(t+1)] = Mtrend
    
    
            # loglikelihood
            constant = log(math.gamma((v + (lag + 1) * k) / 2)) - log(math.gamma(v / 2)) - 0.5 * k * (lag + 1) * log(math.pi * v)
      
            eps = np.flipud(np.matrix(data.iloc[t:t + lag + 1])).flatten().transpose() - Mtrend  # xt(4*1) - M(4*1)            
            d = (1 + 1 / v * np.matmul(np.matmul(eps.transpose(), np.linalg.inv(SIGMA)), eps))
            logliks[t] = constant - 0.5 * log(np.linalg.det(SIGMA)) - 0.5 * (v + (lag + 1) * k) * log(d[0, 0])
        
        loglik = sum(logliks)
    
        if out is False:
            return loglik
        else:
            if Mt_all is False:
                return loglik, logliks, M, SIGMA
            else:
                return loglik, logliks, [namespace['Mt_%d' %(t+1)] for t in range(0, T - lag)], M, SIGMA

    else:
        sys.exit("Trend must be greater than or equal to zero")
        

        
# %% Neg StVAR Likelihood Function (Objective Function for Minimization)
def Neg_St_VAR_likelihood(parameters, data, v, trend, lag, scaled = False, cheby = False):
        return -1 * St_VAR_likelihood(parameters, data, v, trend, lag, scaled, cheby)
    
    

#%% Optimization 

def MLE(starting_vals, data, v, trend, lag, scaled = False, cheby = False):

    start = time.time()
    
    starting_vals= Starting_values(data, trend, lag, scaled, cheby)
    
    estimates_slsqp = fmin_slsqp(Neg_St_VAR_likelihood, starting_vals, args = (data, v ,trend, lag, scaled, cheby), iter=1000,\
        acc=1e-06, iprint=2, full_output=True, epsilon=1.4901161193847656e-8 )

    estimates_bfgs = fmin_bfgs(Neg_St_VAR_likelihood, estimates_slsqp[0], args = (data, v ,trend, lag, scaled, cheby), maxiter=1000,\
       gtol=1e-06, retall = True, full_output=True, epsilon=1.4901161193847656e-8 )

    estimates = minimize(Neg_St_VAR_likelihood, estimates_bfgs[0], args = (data, v, trend, lag, scaled, cheby), method='BFGS',\
                options={'gtol': 1e-06, 'eps': 1.4901161193847656e-08, 'maxiter': 1000, 'disp': True, 'return_all': True})
 
    loglik, logliks, M, SIGMA = St_VAR_likelihood(estimates.x, data, v, trend, lag, scaled, cheby, out= True)
    
    end = time.time()
    print((end-start)/60, "minutes to run the optimazation")   

    return estimates, logliks, M, SIGMA
    
#%%  Score Function I
# The covariance is computed as the outer product of the scores since the scores should have mean 0 
# when evaluated at the solution to the optimization problem.


def score(estimates, data, v, trend, lag, scaled = False, cheby = False):
    step = 1e-6 * estimates
    num = estimates.shape[0]
    T = data.shape[0]
    

    scores = zeros((T-lag,num))
    for i in range(num):
        h = step[i]
        delta = np.zeros(num)
        delta[i] = h
    
        loglik, logliksplus, M, SIGMA = St_VAR_likelihood(estimates + delta, data, v, trend, lag, scaled, cheby, out=True)
        loglik, logliksminus, M, SIGMA = St_VAR_likelihood(estimates - delta, data, v, trend, lag, scaled, cheby, out=True)              
               
        scores[:,i] = (logliksplus - logliksminus)/(2*h)

    I = (scores.T @ scores)/T
    return I

#%% Hessian Function

def hessian_2sided(fun, theta, args):
    f = fun(theta, *args)
    h = 1e-5*np.abs(theta)
    thetah = theta + h
    h = thetah - theta
    K = size(theta,0)
    h = np.diag(h)
    
    fp = zeros(K)
    fm = zeros(K)
    for i in range(K):
        fp[i] = fun(theta+h[i], *args)
        fm[i] = fun(theta-h[i], *args)
        
    fpp = zeros((K,K))
    fmm = zeros((K,K))
    for i in range(K):
        for j in range(i,K):
            fpp[i,j] = fun(theta + h[i] + h[j],  *args)
            fpp[j,i] = fpp[i,j]
            fmm[i,j] = fun(theta - h[i] - h[j],  *args)
            fmm[j,i] = fmm[i,j]
            
    hh = (diag(h))
    hh = hh.reshape((K,1))
    hh = hh @ hh.T
    
    H = zeros((K,K))
    for i in range(K):
        for j in range(i,K):
            H[i,j] = (fpp[i,j] - fp[i] - fp[j] + f 
                       + f - fm[i] - fm[j] + fmm[i,j])/hh[i,j]/2
            H[j,i] = H[i,j]
    
    return H

#%% Variance of Estimation

def Var_estimators (estimates, hess_inv, data, v, trend, lag, scaled = False, cheby = False):
    I = score(estimates, data, v, trend, lag, scaled, cheby)
    Hes = hessian_2sided(St_VAR_likelihood, estimates, args = (data, v, trend, lag, scaled, cheby))

    T = size(data,0)
    J = Hes/T
    #Jinv = mat(inv(J))
    
    #vcv = Jinv*mat(I)*Jinv/T
    vcv = hess_inv
    
    return vcv

#%% Reparametrization

def Reparametrization(estimates, data, v, trend, lag, scaled = False, cheby = False, out = False):

    #T = size(data,0)
    k = size(data,1)
    
    
    if trend == 0:
        # recall parameters
        loglik, logliks, M, SIGMA = St_VAR_likelihood(estimates, data, v, trend, lag, scaled, cheby, out= True)
        
        #Q
        Q = SIGMA[k: k + (lag+1)*k, k: k +(lag+1)*k]
        
        
        #A
        A = np.matmul(SIGMA[0:k,k: k + (lag+1)*k,], np.linalg.inv(Q))
        
        #A1, A2, A3, ..., Al
        namespace = globals()
        
        for l in range (1, lag+1):
            namespace['A_%d' %(l)] = A[0:k, (lag-1)*k:lag*k]
        
        #a
        a = M[0:k] - np.matmul(A, M[k:k*(lag+1)])
        
        #Omega
        Omega = SIGMA[0:k,0:k] - np.matmul(np.matmul(SIGMA[0:k,k: k + (lag+1)*k,], np.linalg.inv(Q)), SIGMA[0:k,k: k + (lag+1)*k,].T)
        
        if out == False:
            return a, A, Omega, Q
        else:
            return a, A, [namespace['A_%d' %(l)] for l in range(1, lag+1)], Omega, Q
    
    elif trend > 0:
        # recall parameters
        loglik, logliks, M, SIGMA = St_VAR_likelihood(estimates, data, v, trend, lag, scaled, cheby, out= True)
        
        #Q
        Q = SIGMA[k: k + (lag+1)*k, k: k +(lag+1)*k ]
        
        
        #A
        A = np.matmul(SIGMA[0:k,k: k + (lag+1)*k,], np.linalg.inv(Q))
        
        #A1, A2, A3, ..., Al
        namespace = globals()
        
        for l in range (1, lag+1):
            namespace['A_%d' %(l)] = A[0:k, (lag-1)*k:lag*k]
            
            
        #Ms
        for t in range (trend+1):
            namespace['M_%d' %(t)] = M[:, t]
            
        #a and deltas
        # t = sym.symbols('t')
        # #a = input("Enter the equation of a: ")
        # solve_b = M_0 + M_1 * t + M_2 * t**2 - np.matmul(A_1 , M_0 + M_1 * (t-1) + M_2 * (t-1)**2) - np.matmul(A_2 , M_0 + M_1 * (t-2) + M_2 * (t-2)**2)

        t = sym.symbols('t')
        a_0 = namespace['M_%d' %(0)]
        for i in range(1, trend+1):
            a_0 =  a_0 +  namespace['M_%d' %(i)] * t**i
 
        solve_a = a_0
        for l in range(1, lag+1):
            namespace['a_%d' %(l)] = namespace['M_%d' %(0)]
            for i in range(1, trend+1):
                namespace['a_%d' %(l)] = namespace['a_%d' %(l)] + namespace['M_%d' %(i)] * t**i
    
        solve_a = solve_a - np.matmul(namespace['A_%d' %(l)], namespace['a_%d' %(l)])
   
                       
        a = sym.Matrix(solve_a).expand()
        # b = sym.Matrix(solve_b).expand()

           
                              
        #deltas
        for j in range(trend+1):
            namespace['delta_%d' %(j)] = np.zeros((k))
    
    
        for i in range(k): 
            for j in range(trend+1): 
                if size(a[i].args) == 0:
                    namespace['delta_%d' %(0)][i] = a[i]
                elif size(a[i].args[j].args) == 0:
                    namespace['delta_%d' %(0)][i] = a[i].args[j]
                elif a[i].args[j].args[1] == t:
                    namespace['delta_%d' %(1)][i] = a[i].args[j].args[0]
                elif a[i].args[j].args[1].args[1] >= 2:
                    for r in range(2, trend+1):
                        if a[i].args[j].args[1].args[1] == r: 
                            namespace['delta_%d' %(r)][i] = a[i].args[j].args[0]
        
        
        # #deltas
        # for i in range(trend+1):    
            
        #     if i == 0:
        #         C = np.zeros((k,1))
        #         for j in range(trend+1):
        #             A_0 = np.ones((k,k))
        #             B = 0**(j-i) * A_0
        #             for l in range(1, lag+1):
        #                 B -  (l**(j-i)) * namespace['A_%d' %(l)]
        #             C + (-1)**(j-i) * B * namespace['M_%d' %(j)]
                
        #     if (i > 0 & i < trend):
        #         C = np.zeros((k,1))
        #         for j in range(trend+1):
        #             if j == i:
        #                 A_0 = np.ones((k,k))
        #                 B = 0**(j-i) * A_0
        #                 for l in range(1, lag+1):
        #                     B -  (l**(j-i)) * namespace['A_%d' %(l)] 
        #                 C + (-1)**(j-i) * B * namespace['M_%d' %(j)]
        #             if j > i:
        #                 A_0 = np.ones((k,k))
        #                 B = 0**(j-i) * A_0
        #                 for l in range(1, lag+1):
        #                     B -  j * (l**(j-i)) * namespace['A_%d' %(l)]
        #                 C + (-1)**(j-i) * B * namespace['M_%d' %(j)]
            
        #     if i == trend:
        #         C = np.zeros((k,1))
        #         A_0 = np.ones((k,k))
        #         B = 0**(i-i) * A_0
        #         for l in range(1, lag+1):        
        #             B - namespace['A_%d' %(l)]
        #         C + (-1)**(i-i) * B * namespace['M_%d' %(i)]
            
        #     namespace['delta_%d' %(i)] = C       

        #Omega
        Omega = SIGMA[0:k,0:k] - np.matmul(np.matmul(SIGMA[0:k,k: k + (lag+1)*k,], np.linalg.inv(Q)), SIGMA[0:k,k: k + (lag+1)*k,].T)                                  
        
        if out == False:
            return [namespace['delta_%d' %(j)] for j in range(trend+1)] , A, Omega, Q
        else:
            return [namespace['delta_%d' %(j)] for j in range(trend+1)] , A, [namespace['A_%d' %(l)] for l in range(1, lag+1)], Omega, Q

#%% Std. Error of conditioal dist. estimations

def std_error(estimates, hess_inv, data, v, trend, lag, scaled = False, cheby = False):
    
    vcv = Var_estimators(estimates, hess_inv, data, v, trend, lag, scaled, cheby) #variance of estimation 
    
    
    step = 1e-6 * estimates
    num = estimates.shape[0]
    #T = size(data,0)
    #k = size(data,1)

    if trend == 0:

        a, A, Omega, Q = Reparametrization(estimates, data, v, trend, lag, scaled, cheby)   
        a_jac = zeros((a.shape[0]*a.shape[1],num))
        A_jac = zeros((A.shape[0]*A.shape[1],num))
        Omega_jac = zeros((Omega.shape[0]*Omega.shape[1],num))

        for i in range(num):
            h = step[i]
            delta = np.zeros(num)
            delta[i] = step[i]
        
            a_plus, A_plus, Omega_plus, Q_plus = Reparametrization(estimates + delta, data, v, trend, lag, scaled, cheby)
            a_minus, A_minus, Omega_minus, Q_minus = Reparametrization(estimates - delta, data, v, trend, lag, scaled, cheby)
    
       
    
            a_J = (a_plus - a_minus)/(2*h)        
            A_J = (A_plus - A_minus)/(2*h)
            Omega_J = (Omega_plus - Omega_minus)/(2*h)

            a_jac[:,i] = a_J.flatten()            
            A_jac[:,i] = A_J.flatten()
            Omega_jac[:,i] = Omega_J.flatten()
 
        
        V = vcv  
        
        se_a = np.sqrt(np.diagonal(np.matmul(np.matmul(a_jac,V),a_jac.T)))
        se_A = np.sqrt(np.diagonal(np.matmul(np.matmul(A_jac,V),A_jac.T)))
        se_Omega = np.sqrt(np.diagonal(np.matmul(np.matmul(Omega_jac,V),Omega_jac.T))) 
        se_estimates = np.sqrt(np.diagonal(V))
        return se_a, se_A, se_Omega, se_estimates 
    
    elif trend > 0:
        namespace = globals()
        a, A, Omega, Q = Reparametrization(estimates, data, v, trend, lag, scaled, cheby)
        a = np.asmatrix(a).T

        for t in range(trend+1):
            namespace['a%d_jac' %(t)] = zeros((a[:,t].shape[0]*a[:,t].shape[1],num))
 
        A_jac = zeros((A.shape[0]*A.shape[1],num))
        Omega_jac = zeros((Omega.shape[0]*Omega.shape[1],num))

        for i in range(num):
            h = step[i]
            delta = np.zeros(num)
            delta[i] = h

            a_plus, A_plus, Omega_plus, Q_plus = Reparametrization(estimates + delta, data, v, trend, lag, scaled, cheby)
            a_minus, A_minus, Omega_minus, Q_minus = Reparametrization(estimates - delta, data, v, trend, lag, scaled, cheby)
    
            a_plus = np.asmatrix(a_plus).T
            a_minus = np.asmatrix(a_minus).T

            for t in range(trend+1):
                namespace['a%d_J' %(t)] = (a_plus[:,t] - a_minus[:,t])/(2*h) 
   
            A_J = (A_plus - A_minus)/(2*h)
            Omega_J = (Omega_plus - Omega_minus)/(2*h)
    
            for t in range(trend+1):
                namespace['a%d_jac' %(t)][:,i] = namespace['a%d_J' %(t)].flatten()
                
            A_jac[:,i] = A_J.flatten()
            Omega_jac[:,i] = Omega_J.flatten()

        V = vcv  
        for t in range(trend+1):
            namespace['se_a%d' %(t)] =\
                    np.sqrt(np.diagonal(np.matmul(np.matmul(namespace['a%d_jac' %(t)],V),namespace['a%d_jac' %(t)].T)))
        se_A = np.sqrt(np.diagonal(np.matmul(np.matmul(A_jac,V),A_jac.T)))
        se_Omega = np.sqrt(np.diagonal(np.matmul(np.matmul(Omega_jac,V),Omega_jac.T))) 
        se_estimates = np.sqrt(np.diagonal(V))
 
         
        return [namespace['se_a%d' %(t)] for t in range(trend+1)] , se_A, se_Omega, se_estimates
     
    
    
# se_a, se_A, se_Omega = std_error(estimates, returns, 4, 0, 2)


#%% Estimation function

def StVAR_est (data, v, trend, lag, scaled = False, cheby = False):
    
    start = time.time()
    
    starting_vals= Starting_values(data, trend, lag, scaled, cheby)
    loglik = St_VAR_likelihood(starting_vals, data, v, trend, lag, scaled, cheby)
    print("optimazation starting value :", loglik)
    
    path = []
    def reporter(p):
        """Reporter function to capture intermediate states of optimization."""
        value = St_VAR_likelihood(p, data, v, trend, lag, scaled, cheby)
        path.append(value)
        print("Iteration",size(path),": ",value)
    
    print("SLSQP optimization :")
    estimate_SLSQP = minimize(Neg_St_VAR_likelihood, starting_vals, args =(data, v, trend, lag, scaled, cheby), method='SLSQP', jac=None, bounds=None, constraints=(), tol=None, callback=reporter,\
      options={'maxiter': 100, 'ftol': 1e-06, 'iprint': 1, 'disp': False, 'eps': 1.4901161193847656e-08, 'finite_diff_rel_step': None})
    
    step1 = time.time()
    print((step1-start)/60, "minutes to run the 1st optimazation")
    
    if np.isnan(estimate_SLSQP.fun) == False:
            
        print("BFGS complimantary optimization :")
        estimate_BFGS = minimize(Neg_St_VAR_likelihood, estimate_SLSQP.x, args =(data, v, trend, lag, scaled, cheby), method="BFGS", callback=reporter,\
             tol=None, options={'gtol': 1e-04, 'norm': math.inf, 'eps': 1.4901161193847656e-08, 'maxiter': None, 'disp': True, 'return_all': False, 'finite_diff_rel_step': None})
            
        step2 = time.time()
        print((step2-step1)/60, "minutes to run the 2nd optimazation")    
            
        plt.plot(path, color='tomato', marker='o', linestyle='solid')
        plt.show()
            
        #estimation results
        estimates = estimate_BFGS.x
        hess_inv = estimate_BFGS.hess_inv
        jac = estimate_BFGS.jac
            
        # reparametrization and std errors
        #Var_estimators (estimates, data, v, trend, lag)
        a, A, Omega, Q = Reparametrization(estimates, data, v, trend, lag, scaled, cheby, out = False)
        se_a , se_A, se_Omega, se_estimates = std_error(estimates, hess_inv, data, v, trend, lag, scaled, cheby)
            
        step3 = time.time()
        print((step3-step2)/60, "minutes to reparametrize and std. error") 
        
        return a, se_a, A, se_A, Omega, se_Omega, Q, estimates, se_estimates, hess_inv, jac
    
    if np.isnan(estimate_SLSQP.fun) == True:
        print("Houston! we have a problem.")
  

    end = time.time()
    print((end-start)/60, "minutes to run the whole process")   
    
    
    
    
#%% Conditional Mean (Regression) and Conditional Variance (Skedastic)

# Conditional Mean Function
def CMean (data, v, trend, lag, t, a, A, scaled = False, cheby = False):
    
    if trend == 0:
        if scaled == True or cheby == True:
            sys.exit("Trend must be greater than or equal to zero for scaling to be relevant")
        
        elif scaled == False and cheby == False:
            return np.matrix(a) + np.matmul(A, np.flipud(np.matrix(data.iloc[(t-1)-lag:t-1])).flatten().transpose())

    if trend > 0:
        if scaled == True and cheby == False:
            #sc_t = scaled_t(data)
            n = size(data,0)
            
            at = a[0]
            for i in range(1,trend+1):
                at = at + a[i] *(((2*t-n-1)/(n-1))**i)
                
        
        elif scaled ==True and cheby == True:
            #sc_t = scaled_t(data)
            n = size(data,0)
            tk = sym.symbols('tk')
            
            at = a[0]
            for i in range(1,trend+1):
                constant = ((-1)**i*2**i*math.factorial(i))/(math.factorial(2*i))
                w = (1 - tk**2)**(0.5)
                der = (1 - tk**2)**(i-0.5)
                ddt = sym.diff(der,tk,i) 
                poly = sym.expand(constant*w*ddt)                
                
                f = sym.lambdify(tk,poly)
                t_s = (2*t-n-1)/(n-1)
                at = at + a[i]*f(t_s)
            
        elif scaled ==False and cheby == False:
            
            at = a[0]
            for i in range(1,trend+1):
                at = at + a[i] * t**i
              
        return np.matrix(at).transpose() + np.matmul(A, np.flipud(np.matrix(data.iloc[(t-1)-lag:t-1])).flatten().transpose())
    

# CMean (data, 4, 1, 2, 98, a, A)

# Conditioanl Variance Function
def CVar (data, v, trend, lag, t, Q, Omega, estimates, scaled = False, cheby = False):
    k = size(data,1)
    Q_inv = np.linalg.inv(Q)
    
    if trend == 0:
        loglik, logliks, M, SIGMA = St_VAR_likelihood(estimates, data, v, trend, lag, scaled, cheby, out= True)
        e = np.flipud(np.matrix(data.iloc[(t-1)-lag:t-1])).flatten().transpose() - np.matrix(M[k:k*(lag+1)])
        q = 1 + 1/v * np.matmul(np.matmul(e.T,Q_inv),e)
        #scaler = (v/(v+lag*k-2)) * q[0,0] #Niraj Thesis
        scaler = ((v+lag*k)/(v+lag*k-2)) * q[0,0]
        return Omega * scaler

    if trend > 0:
        loglik, logliks, Mt, M, SIGMA = St_VAR_likelihood(estimates, data, v, trend, lag, scaled, cheby, out= True, Mt_all=True)
        e = np.flipud(np.matrix(data.iloc[(t-1)-lag:t-1])).flatten().transpose() - np.matrix(Mt[t-1-lag][k:k*(lag+1)])
        q = 1 + 1/v * np.matmul(np.matmul(e.T,Q_inv),e)
        #scaler = (v/(v+lag*k-2)) * q[0,0] #Niraj Thesis
        scaler = ((v+lag*k)/(v+lag*k-2)) * q[0,0]
        return Omega * scaler

# CVar (data, 4, 0, 2, 20)


def Var_Cov (data, v, trend, lag, Q, Omega, estimates, scaled = False, cheby = False):
    namespace = globals()
    T = size(data,0)
    k = size(data,1)
    
    for i in range(k):
        namespace['Var_y%d' %(i+1)] = []
        for t in range(lag+1, T+1):
            namespace['Var_y%d' %(i+1)].append(np.matrix(CVar(data, v, trend, lag, t, Q, Omega, estimates, scaled, cheby))[i,i])
        for j in range(k):
            if j > i:
                namespace['Cov_y%dy%d' %(i+1,j+1)] = []
                for t in range(lag+1, T+1):
                    namespace['Cov_y%dy%d' %(i+1,j+1)].append(np.matrix(CVar(data, v, trend, lag, t, Q, Omega, estimates,  scaled, cheby))[i,j])
     
    
    Var_Cov = data.iloc[lag:,:]
    namespace = globals()
    
    
    for i in range (data.shape[1]):
        Var_Cov.rename(columns={Var_Cov.columns[i] : 'y'+str(i+1)}, inplace = True)
        Var_Cov['Var_y'+str(i+1)] = namespace['Var_y%d' %(i+1)]
        Var_Cov['Vol_y'+str(i+1)] = np.sqrt(namespace['Var_y%d' %(i+1)])  
    
    for i in range (data.shape[1]):
        for j in range(k):
            if j>i:
               Var_Cov['Cov_y'+str(i+1)+'y'+str(j+1)] = namespace['Cov_y%dy%d' %(i+1,j+1)]
          
     
    return Var_Cov    
    
    #return [namespace['Var_y%d' %(i+1)] for i in range(k)], [namespace['Cov_y%dy%d' %(i+1,j+1)] for i in range(k) for j in range(k) if j>i]

# Var_Cov (data, 4, 0, 2)



#%% Fitted Values and Residuals

# Standardized Residuals
def Resid (data, v, trend, lag, t, a, A, Q, Omega, estimates, scaled = False, cheby = False):
    resid = np.flipud(np.matrix(data.iloc[t-1:t])).flatten().transpose() - CMean (data, v, trend, lag, t, a, A, scaled, cheby)
    L = la.cholesky(CVar (data, v, trend, lag, t, Q, Omega, estimates, scaled, cheby))
    return np.matmul(np.linalg.inv(L), resid)


#Spanos Residuals
def Spanos_Resid(data, v, trend, lag, t, a, A, Q, Omega, estimates, scaled = False, cheby = False):
    resid = np.flipud(np.matrix(data.iloc[t-1:t])).flatten().transpose() - CMean (data, v, trend, lag, t, a, A, scaled, cheby)
    L = la.cholesky(CVar (data, v, trend, lag, t, Q, Omega, estimates, scaled, cheby))
    
    T = size(data,0)
    k = size(data,1)
    St_resid = []
    for t in range (lag+1,T+1):
        St_resid[t-(lag+1):] = Multivariate_St_rvs(np.zeros(k), np.identity(k), (v+lag*k), 1)
    
    fml = np.matmul(L,St_resid[t-(lag+1)])
    fml = np.reshape(fml, (size(fml),1))
    return np.matmul(np.linalg.inv(L), resid) - fml

# fitting
def fit(data, v, trend, lag, a, A, Q, Omega, estimates, scaled = False, cheby = False):
    namespace = globals()
    T = size(data,0)
    k = size(data,1)
    
    for i in range(k):
        namespace['hat_y%d' %(i+1)] = []
        namespace['resid_y%d' %(i+1)] = []
        namespace['Spanos_resid_y%d' %(i+1)] = []
        
        for t in range(lag+1, T+1):
            namespace['hat_y%d' %(i+1)][t-(lag+1):] = np.asarray(CMean(data, v, trend, lag, t, a, A, scaled, cheby))[i]
            namespace['resid_y%d' %(i+1)][t-(lag+1):] = np.asarray(Resid (data, v, trend, lag, t, a, A, Q, Omega, estimates, scaled, cheby))[i]
            namespace['Spanos_resid_y%d' %(i+1)][t-(lag+1):] = np.asarray(Spanos_Resid(data, v, trend, lag, t, a, A, Q, Omega, estimates, scaled, cheby))[i]
     
    # Return a DataFrame       
    Fit = data.iloc[lag:,:]
    namespace = globals()
        
    for i in range (data.shape[1]):
        Fit.rename(columns={Fit.columns[i] : 'y'+str(i+1)}, inplace = True)
        Fit['hat_y'+str(i+1)] = namespace['hat_y%d' %(i+1)]
        Fit['resid_y'+str(i+1)] = namespace['resid_y%d' %(i+1)]
        Fit['Spanos_resid_y'+str(i+1)] = namespace['resid_y%d' %(i+1)]
        
    return Fit
        
#Adjusted Fitted Values
def Adj_fit(data, v, trend, lag, a, A, Q, Omega, estimates, fit,  scaled = False, cheby = False):
    T = size(data,0)
    k = size(data,1)
    #s = (v +lag*k-2)/(v+lag*k)
    s = (v +lag*k-2)/(v)
    
    St_adj = []
    for t in range (lag+1, T+1):
        St_adj[t-(lag+1):] = Multivariate_St_rvs(np.zeros(k), s*CVar(data, v, trend, lag, t, Q, Omega, estimates, scaled, cheby), (v+lag*k), 1)
        
    St_adj = np.asarray(St_adj)
    
    namespace = globals()
    for i in range(k):
        namespace['hathat_y%d' %(i+1)] = fit['hat_y%d' %(i+1)] + St_adj[:,i]
        
    
    # Return a DataFrame       
    Adj_Fit = data.iloc[lag:,:]
    namespace = globals()
        
    for i in range (data.shape[1]):
        Adj_Fit.rename(columns={Adj_Fit.columns[i] : 'y'+str(i+1)}, inplace = True)
        Adj_Fit['hathat_y'+str(i+1)] = namespace['hathat_y%d' %(i+1)]
        Adj_Fit['St_adj_y'+str(i+1)] = St_adj[:,i]
        
        
    return Adj_Fit 
        

#%% time variable

def t_make(t1, t2): 
  
    # Testing if range r1 and r2 are equal 
    if (t1 == t2): 
        return t1 
  
    else: 
  
        # Create empty list 
        t = [] 
  
        # loop to append successors to list until t2 is reached. 
        while(t1 < t2+1 ): 
              
            t.append(t1) 
            t1 += 1
        return t 


#%% Regression Visualization

def fig_reg(model): 

    plt.rc('figure', figsize=(12, 7))
    #plt.text(0.01, 0.05, str(model.summary()), {'fontsize': 12}) old approach
    plt.text(0.01, 0.05, str(model.summary()), {'fontsize': 10}, fontproperties = 'monospace') # approach improved by OP -> monospace!
    plt.axis('off')
    #plt.tight_layout()
    plt.show()
    #plt.savefig('output.png')
    

#%% MS testing and Auxilliary Regressions Function base

def MS_testing_base(data, v, trend, lag, scaled = False, cheby = False):
    #Making a DataFrame collecting all data needed for MS testing
    T = size(data,0)
    MS_df = data.iloc[lag:,:]
    namespace = globals()
    
    
    for i in range (data.shape[1]):
        MS_df.rename(columns={MS_df.columns[i] : 'y'+str(i+1)}, inplace = True)
        MS_df['hat_y'+str(i+1)] = namespace['hat_y%d' %(i+1)]
        MS_df['hathat_y'+str(i+1)] = namespace['hathat_y%d' %(i+1)]
        MS_df['resid_y'+str(i+1)] = namespace['resid_y%d' %(i+1)]
        MS_df['Spanos_resid_y'+str(i+1)] = namespace['Spanos_resid_y%d' %(i+1)]
        MS_df['hat_volatility_y'+str(i+1)] = np.sqrt(namespace['Var_y%d' %(i+1)])
    
    MS_df['t'] = t_make(lag+1, T) #ordinary time
    MS_df['t_s'] = scaled_t(data)[lag:] #scaled time 
    for i in range(1, trend+4):
        MS_df['t_cheby1^'+str(i)] = np.asarray(Chebyshev_poly(scaled_t(data), trend+3).iloc[lag:,i]) #orthogonal time polynomials
    
    #MS_df.set_index('t') 
    
    
    
    # Residuals and squared residuals with ordinary fitted value like hat_y1
    for i in range (data.shape[1]):
        namespace['resid_y%d' %(i+1)] = np.asarray(MS_df['resid_y%d' %(i+1)])
        
    for i in range (data.shape[1]):
        namespace['s_resid_y%d' %(i+1)] = np.asarray(MS_df['resid_y%d' %(i+1)])**2
    
    # Unrestrcited  and restricted Models - Residuals
    for i in range (data.shape[1]):
    
        X = np.c_[np.ones(T-lag)]
        X = pd.DataFrame(X, columns=['constant'])
        
        for j in range (data.shape[1]):
            
            for s in range(1, lag+1):
                X['L'+str(s)+'.y'+str(j+1)] = np.asarray(MS_df['y'+str(j+1)].shift(s))
        
            for s in range(1,lag+1):
                X['L'+str(s)+'.y'+str(j+1)+'^2'] = np.asarray(MS_df['y'+str(j+1)].shift(s)**2)
        
        for s in range(1,lag+1+2):
            X['L'+str(s)+'.resid_y'+str(i+1)] = np.asarray(MS_df['resid_y'+str(i+1)].shift(s))
        
        if scaled == False and cheby == False:
            X['t'+str(trend+1)] = np.asarray(MS_df['t']**(trend+1))
            X['t'+str(trend+2)] = np.asarray(MS_df['t']**(trend+2))
            X['t'+str(trend+3)] = np.asarray(MS_df['t']**(trend+3))
            
        elif scaled == True and cheby == False:      
            X['t'+str(trend+1)] = np.asarray(MS_df['t_s']**(trend+1))
            X['t'+str(trend+2)] = np.asarray(MS_df['t_s']**(trend+2))
            X['t'+str(trend+3)] = np.asarray(MS_df['t_s']**(trend+3))
            
        elif scaled == True and cheby == True:     
            X['t'+str(trend+1)] = np.asarray(MS_df['t_cheby1^'+str(trend+1)])
            X['t'+str(trend+2)] = np.asarray(MS_df['t_cheby1^'+str(trend+2)])
            X['t'+str(trend+3)] = np.asarray(MS_df['t_cheby1^'+str(trend+3)])
                
                
        namespace['Xu%d' %(i+1)] = X
    
    # Restricted models
    ## Linearity r2 
    for i in range (data.shape[1]):
    
        X = np.c_[np.ones(T-lag)]
        X = pd.DataFrame(X, columns=['constant'])
        
        for j in range (data.shape[1]):
            
            for s in range(1, lag+1):
                X['L'+str(s)+'.y'+str(j+1)] = np.asarray(MS_df['y'+str(j+1)].shift(s))
        
            #for s in range(1,lag+1):
                #X['L'+str(s)+'.y'+str(j+1)+'^2'] = np.asarray(MS_df['y'+str(j+1)].shift(s)**2)
        
        for s in range(1,lag+1+2):
            X['L'+str(s)+'.resid_y'+str(i+1)] = np.asarray(MS_df['resid_y'+str(i+1)].shift(s))
        
        if scaled == False and cheby == False:
            X['t'+str(trend+1)] = np.asarray(MS_df['t']**(trend+1))
            X['t'+str(trend+2)] = np.asarray(MS_df['t']**(trend+2))
            X['t'+str(trend+3)] = np.asarray(MS_df['t']**(trend+3))
            
        elif scaled == True and cheby == False:      
            X['t'+str(trend+1)] = np.asarray(MS_df['t_s']**(trend+1))
            X['t'+str(trend+2)] = np.asarray(MS_df['t_s']**(trend+2))
            X['t'+str(trend+3)] = np.asarray(MS_df['t_s']**(trend+3))
            
        elif scaled == True and cheby == True:     
            X['t'+str(trend+1)] = np.asarray(MS_df['t_cheby1^'+str(trend+1)])
            X['t'+str(trend+2)] = np.asarray(MS_df['t_cheby1^'+str(trend+2)])
            X['t'+str(trend+3)] = np.asarray(MS_df['t_cheby1^'+str(trend+3)])
                
        namespace['Xu%d_r2' %(i+1)] = X
    
    ## Markov r4
    for i in range (data.shape[1]):
    
        X = np.c_[np.ones(T-lag)]
        X = pd.DataFrame(X, columns=['constant'])
        
        for j in range (data.shape[1]):
            
            for s in range(1, lag+1):
                X['L'+str(s)+'.y'+str(j+1)] = np.asarray(MS_df['y'+str(j+1)].shift(s))
        
            for s in range(1,lag+1):
                X['L'+str(s)+'.y'+str(j+1)+'^2'] = np.asarray(MS_df['y'+str(j+1)].shift(s)**2)
        
        #for s in range(1,lag+1+2):
            #X['L'+str(s)+'.resid_y'+str(i+1)] = np.asarray(MS_df['resid_y'+str(i+1)].shift(s))
        
        if scaled == False and cheby == False:
            X['t'+str(trend+1)] = np.asarray(MS_df['t']**(trend+1))
            X['t'+str(trend+2)] = np.asarray(MS_df['t']**(trend+2))
            X['t'+str(trend+3)] = np.asarray(MS_df['t']**(trend+3))
            
        elif scaled == True and cheby == False:      
            X['t'+str(trend+1)] = np.asarray(MS_df['t_s']**(trend+1))
            X['t'+str(trend+2)] = np.asarray(MS_df['t_s']**(trend+2))
            X['t'+str(trend+3)] = np.asarray(MS_df['t_s']**(trend+3))
            
        elif scaled == True and cheby == True:     
            X['t'+str(trend+1)] = np.asarray(MS_df['t_cheby1^'+str(trend+1)])
            X['t'+str(trend+2)] = np.asarray(MS_df['t_cheby1^'+str(trend+2)])
            X['t'+str(trend+3)] = np.asarray(MS_df['t_cheby1^'+str(trend+3)])
                
        namespace['Xu%d_r4' %(i+1)] = X
    
    ##1st moment t-invariance r5
    for i in range (data.shape[1]):
    
        X = np.c_[np.ones(T-lag)]
        X = pd.DataFrame(X, columns=['constant'])
        
        for j in range (data.shape[1]):
            
            for s in range(1, lag+1):
                X['L'+str(s)+'.y'+str(j+1)] = np.asarray(MS_df['y'+str(j+1)].shift(s))
        
            for s in range(1,lag+1):
                X['L'+str(s)+'.y'+str(j+1)+'^2'] = np.asarray(MS_df['y'+str(j+1)].shift(s)**2)
        
        for s in range(1,lag+1+2):
            X['L'+str(s)+'.resid_y'+str(i+1)] = np.asarray(MS_df['resid_y'+str(i+1)].shift(s))
        
        # if scaled == False and cheby == False:
        #     X['t'+str(trend+1)] = np.asarray(MS_df['t']**(trend+1))
        #     X['t'+str(trend+2)] = np.asarray(MS_df['t']**(trend+2))
        #     X['t'+str(trend+3)] = np.asarray(MS_df['t']**(trend+3))
            
        # elif scaled == True and cheby == False:      
        #     X['t'+str(trend+1)] = np.asarray(MS_df['t_s']**(trend+1))
        #     X['t'+str(trend+2)] = np.asarray(MS_df['t_s']**(trend+2))
        #     X['t'+str(trend+3)] = np.asarray(MS_df['t_s']**(trend+3))
            
        # elif scaled == True and cheby == True:     
        #     X['t'+str(trend+1)] = np.asarray(MS_df['t_cheby1^'+str(trend+1)])
        #     X['t'+str(trend+2)] = np.asarray(MS_df['t_cheby1^'+str(trend+2)])
        #     X['t'+str(trend+3)] = np.asarray(MS_df['t_cheby1^'+str(trend+3)])
                
        namespace['Xu%d_r5' %(i+1)] = X
        
    
    # Unrestrcited  and restricted Model - Squared Residuals
    for i in range (data.shape[1]):
    
        X = np.c_[np.ones(T-lag)]
        X = pd.DataFrame(X, columns=['constant'])
        
        for j in range (data.shape[1]):
            
            for s in range(1, lag+1):
                X['L'+str(s)+'.y'+str(j+1)] = np.asarray(MS_df['y'+str(j+1)].shift(s))
        
            for s in range(1,lag+1+2):
                X['L'+str(s)+'.y'+str(j+1)+'^2'] = np.asarray(MS_df['y'+str(j+1)].shift(s)**2)
        
        for s in range(1,lag+1+2):
            X['L'+str(s)+'.resid_y'+str(i+1)+'^2'] = np.asarray(MS_df['resid_y'+str(i+1)].shift(s)**2)
        
        if scaled == False and cheby == False:
            X['t'+str(trend+1)] = np.asarray(MS_df['t']**(trend+1))
            X['t'+str(trend+2)] = np.asarray(MS_df['t']**(trend+2))
            X['t'+str(trend+3)] = np.asarray(MS_df['t']**(trend+3))
            
        elif scaled == True and cheby == False:      
            X['t'+str(trend+1)] = np.asarray(MS_df['t_s']**(trend+1))
            X['t'+str(trend+2)] = np.asarray(MS_df['t_s']**(trend+2))
            X['t'+str(trend+3)] = np.asarray(MS_df['t_s']**(trend+3))
            
        elif scaled == True and cheby == True:     
            X['t'+str(trend+1)] = np.asarray(MS_df['t_cheby1^'+str(trend+1)])
            X['t'+str(trend+2)] = np.asarray(MS_df['t_cheby1^'+str(trend+2)])
            X['t'+str(trend+3)] = np.asarray(MS_df['t_cheby1^'+str(trend+3)])
                
        namespace['Xs%d' %(i+1)] = X
    
    # Restricted models
    ## Second Order Dependence r3
    for i in range (data.shape[1]):
    
        X = np.c_[np.ones(T-lag)]
        X = pd.DataFrame(X, columns=['constant'])
        
        for j in range (data.shape[1]):
            
            for s in range(1, lag+1):
                X['L'+str(s)+'.y'+str(j+1)] = np.asarray(MS_df['y'+str(j+1)].shift(s))
        
            for s in range(lag+1,lag+1+2):
                X['L'+str(s)+'.y'+str(j+1)+'^2'] = np.asarray(MS_df['y'+str(j+1)].shift(s)**2)
        
        #for s in range(1,lag+1+2):
            #X['L'+str(s)+'.resid_y'+str(i+1)+'^2'] = np.asarray(MS_df['resid_y'+str(i+1)].shift(s)**2)
        
        if scaled == False and cheby == False:
            X['t'+str(trend+1)] = np.asarray(MS_df['t']**(trend+1))
            X['t'+str(trend+2)] = np.asarray(MS_df['t']**(trend+2))
            X['t'+str(trend+3)] = np.asarray(MS_df['t']**(trend+3))
            
        elif scaled == True and cheby == False:      
            X['t'+str(trend+1)] = np.asarray(MS_df['t_s']**(trend+1))
            X['t'+str(trend+2)] = np.asarray(MS_df['t_s']**(trend+2))
            X['t'+str(trend+3)] = np.asarray(MS_df['t_s']**(trend+3))
            
        elif scaled == True and cheby == True:     
            X['t'+str(trend+1)] = np.asarray(MS_df['t_cheby1^'+str(trend+1)])
            X['t'+str(trend+2)] = np.asarray(MS_df['t_cheby1^'+str(trend+2)])
            X['t'+str(trend+3)] = np.asarray(MS_df['t_cheby1^'+str(trend+3)])
                
        namespace['Xs%d_r3' %(i+1)] = X
        
    ## Homoskedasticity r3_1
    for i in range (data.shape[1]):
    
        X = np.c_[np.ones(T-lag)]
        X = pd.DataFrame(X, columns=['constant'])
        
        for j in range (data.shape[1]):
            
            #for s in range(1, lag+1):
                #X['L'+str(s)+'.y'+str(j+1)] = np.asarray(MS_df['y'+str(j+1)].shift(s))
        
            for s in range(lag+1,lag+1+2):
                X['L'+str(s)+'.y'+str(j+1)+'^2'] = np.asarray(MS_df['y'+str(j+1)].shift(s)**2)
        
        for s in range(1,lag+1+2):
            X['L'+str(s)+'.resid_y'+str(i+1)+'^2'] = np.asarray(MS_df['resid_y'+str(i+1)].shift(s)**2)
        
        if scaled == False and cheby == False:
            X['t'+str(trend+1)] = np.asarray(MS_df['t']**(trend+1))
            X['t'+str(trend+2)] = np.asarray(MS_df['t']**(trend+2))
            X['t'+str(trend+3)] = np.asarray(MS_df['t']**(trend+3))
            
        elif scaled == True and cheby == False:      
            X['t'+str(trend+1)] = np.asarray(MS_df['t_s']**(trend+1))
            X['t'+str(trend+2)] = np.asarray(MS_df['t_s']**(trend+2))
            X['t'+str(trend+3)] = np.asarray(MS_df['t_s']**(trend+3))
            
        elif scaled == True and cheby == True:     
            X['t'+str(trend+1)] = np.asarray(MS_df['t_cheby1^'+str(trend+1)])
            X['t'+str(trend+2)] = np.asarray(MS_df['t_cheby1^'+str(trend+2)])
            X['t'+str(trend+3)] = np.asarray(MS_df['t_cheby1^'+str(trend+3)])
                
        namespace['Xs%d_r3.1' %(i+1)] = X
    
    ## Dynamic Homoskedasticity r3_2 
    for i in range (data.shape[1]):
    
        X = np.c_[np.ones(T-lag)]
        X = pd.DataFrame(X, columns=['constant'])
        
        for j in range (data.shape[1]):
            
            for s in range(1, lag+1):
                X['L'+str(s)+'.y'+str(j+1)] = np.asarray(MS_df['y'+str(j+1)].shift(s))
        
            for s in range(1,lag+1):
                X['L'+str(s)+'.y'+str(j+1)+'^2'] = np.asarray(MS_df['y'+str(j+1)].shift(s)**2)
        
        for s in range(1,lag+1+2):
            X['L'+str(s)+'.resid_y'+str(i+1)+'^2'] = np.asarray(MS_df['resid_y'+str(i+1)].shift(s)**2)
        
        if scaled == False and cheby == False:
            X['t'+str(trend+1)] = np.asarray(MS_df['t']**(trend+1))
            X['t'+str(trend+2)] = np.asarray(MS_df['t']**(trend+2))
            X['t'+str(trend+3)] = np.asarray(MS_df['t']**(trend+3))
            
        elif scaled == True and cheby == False:      
            X['t'+str(trend+1)] = np.asarray(MS_df['t_s']**(trend+1))
            X['t'+str(trend+2)] = np.asarray(MS_df['t_s']**(trend+2))
            X['t'+str(trend+3)] = np.asarray(MS_df['t_s']**(trend+3))
            
        elif scaled == True and cheby == True:     
            X['t'+str(trend+1)] = np.asarray(MS_df['t_cheby1^'+str(trend+1)])
            X['t'+str(trend+2)] = np.asarray(MS_df['t_cheby1^'+str(trend+2)])
            X['t'+str(trend+3)] = np.asarray(MS_df['t_cheby1^'+str(trend+3)])
                
        namespace['Xs%d_r3.2' %(i+1)] = X
    
    ##2nd moment t-invariance r6
    for i in range (data.shape[1]):
    
        X = np.c_[np.ones(T-lag)]
        X = pd.DataFrame(X, columns=['constant'])
        
        for j in range (data.shape[1]):
            
            for s in range(1, lag+1):
                X['L'+str(s)+'.y'+str(j+1)] = np.asarray(MS_df['y'+str(j+1)].shift(s))
        
            for s in range(lag+1,lag+1+2):
                X['L'+str(s)+'.y'+str(j+1)+'^2'] = np.asarray(MS_df['y'+str(j+1)].shift(s)**2)
        
        for s in range(1,lag+1+2):
            X['L'+str(s)+'.resid_y'+str(i+1)+'^2'] = np.asarray(MS_df['resid_y'+str(i+1)].shift(s)**2)
        
        # if scaled == False and cheby == False:
        #     X['t'+str(trend+1)] = np.asarray(MS_df['t']**(trend+1))
        #     X['t'+str(trend+2)] = np.asarray(MS_df['t']**(trend+2))
        #     X['t'+str(trend+3)] = np.asarray(MS_df['t']**(trend+3))
            
        # elif scaled == True and cheby == False:      
        #     X['t'+str(trend+1)] = np.asarray(MS_df['t_s']**(trend+1))
        #     X['t'+str(trend+2)] = np.asarray(MS_df['t_s']**(trend+2))
        #     X['t'+str(trend+3)] = np.asarray(MS_df['t_s']**(trend+3))
            
        # elif scaled == True and cheby == True:     
        #     X['t'+str(trend+1)] = np.asarray(MS_df['t_cheby1^'+str(trend+1)])
        #     X['t'+str(trend+2)] = np.asarray(MS_df['t_cheby1^'+str(trend+2)])
        #     X['t'+str(trend+3)] = np.asarray(MS_df['t_cheby1^'+str(trend+3)])
                
        namespace['Xs%d_r6' %(i+1)] = X
    
    # MS Auxiliary Regressions 
    ## Residuals
    for i in range (data.shape[1]):
    
        # Note the difference in argument order
        namespace['Modelu_y%d' %(i+1)] = sm.OLS(namespace['resid_y%d' %(i+1)][lag+2:], namespace['Xu%d' %(i+1)].dropna()).fit()
        namespace['Modelu_y%d_r2' %(i+1)] = sm.OLS(namespace['resid_y%d' %(i+1)][lag+2:], namespace['Xu%d_r2' %(i+1)].dropna()).fit()
        namespace['Modelu_y%d_r4' %(i+1)] = sm.OLS(namespace['resid_y%d' %(i+1)][lag:], namespace['Xu%d_r4' %(i+1)].dropna()).fit()
        namespace['Modelu_y%d_r5' %(i+1)] = sm.OLS(namespace['resid_y%d' %(i+1)][lag+2:], namespace['Xu%d_r5' %(i+1)].dropna()).fit()
        #predictions = model.predict(X) # make the predictions by the model
        
    ## Squared Residuals
    for i in range (data.shape[1]):
    
        # Note the difference in argument order
        namespace['Models_y%d' %(i+1)] = sm.OLS(namespace['s_resid_y%d' %(i+1)][lag+2:], namespace['Xs%d' %(i+1)].dropna()).fit()
        namespace['Models_y%d_r3' %(i+1)] = sm.OLS(namespace['s_resid_y%d' %(i+1)][lag+2:]**2, namespace['Xs%d_r3' %(i+1)].dropna()).fit()
        namespace['Models_y%d_r3.1' %(i+1)] = sm.OLS(namespace['s_resid_y%d' %(i+1)][lag+2:]**2, namespace['Xs%d_r3.1' %(i+1)].dropna()).fit()
        namespace['Models_y%d_r3.2' %(i+1)] = sm.OLS(namespace['s_resid_y%d' %(i+1)][lag+2:]**2, namespace['Xs%d_r3.2' %(i+1)].dropna()).fit()
        namespace['Models_y%d_r6' %(i+1)] = sm.OLS(namespace['s_resid_y%d' %(i+1)][lag+2:]**2, namespace['Xs%d_r6' %(i+1)].dropna()).fit()
        #predictions = model.predict(X) # make the predictions by the model
    
    
    
    
    # Print out the statistics
    for i in range (data.shape[1]):
    
        #print(namespace['Model_y%d' %(i+1)].summary())
        fig_reg(namespace['Modelu_y%d' %(i+1)])
        
        #print(namespace['Model_y%d_r2' %(i+1)].summary())
        fig_reg(namespace['Modelu_y%d_r2' %(i+1)])
        
        #print(namespace['Model_y%d_r4' %(i+1)].summary())
        fig_reg(namespace['Modelu_y%d_r4' %(i+1)])
        
        #print(namespace['Model_y%d_r5' %(i+1)].summary())
        fig_reg(namespace['Modelu_y%d_r5' %(i+1)])
        
        #print(namespace['Model_y%d' %(i+1)].summary())
        fig_reg(namespace['Models_y%d' %(i+1)])
        
        #print(namespace['Model_y%d_r3' %(i+1)].summary())
        fig_reg(namespace['Models_y%d_r3' %(i+1)])
        
        #print(namespace['Model_y%d_r3.1' %(i+1)].summary())
        fig_reg(namespace['Models_y%d_r3.1' %(i+1)])
        
        #print(namespace['Model_y%d_r3.2' %(i+1)].summary())
        fig_reg(namespace['Models_y%d_r3.2' %(i+1)])
        
        #print(namespace['Model_y%d_r6' %(i+1)].summary())
        fig_reg(namespace['Models_y%d_r6' %(i+1)])
    
    
    # MS testing report 
    for i in range (data.shape[1]):
        print('equation: y'+str(i+1))
        print('H0:', 'f_value', 'p_value', 'df_diff')
        
        print('r2: ', namespace['Modelu_y%d' %(i+1)].compare_f_test(namespace['Modelu_y%d_r2' %(i+1)]))
        print('r4: ', namespace['Modelu_y%d' %(i+1)].compare_f_test(namespace['Modelu_y%d_r4' %(i+1)]))
        print('r5: ', namespace['Modelu_y%d' %(i+1)].compare_f_test(namespace['Modelu_y%d_r5' %(i+1)]))
        
        print('r3: ', namespace['Models_y%d' %(i+1)].compare_f_test(namespace['Models_y%d_r3' %(i+1)]))
        print('r3.1: ', namespace['Models_y%d' %(i+1)].compare_f_test(namespace['Models_y%d_r3.1' %(i+1)]))
        print('r3.2: ', namespace['Models_y%d' %(i+1)].compare_f_test(namespace['Models_y%d_r3.2' %(i+1)]))
        print('r6:   ', namespace['Models_y%d' %(i+1)].compare_f_test(namespace['Models_y%d_r6' %(i+1)]))
    
        #if  namespace['Modelu_y%d' %(i+1)].compare_f_test(namespace['Modelu_y%d_r2' %(i+1)])[1] :
            
            
            
            
    ## Anderson - Darling Normality Test 
        #Anderson-Darling test for data coming from a particular distribution. 
        #The Anderson-Darling tests the null hypothesis that a sample is drawn from a population that follows a particular distribution.
        #For the Anderson-Darling test, the critical values depend on which distribution is being tested against.
        #This function works for normal, exponential, logistic, or Gumbel (Extreme Value Type I) distributions. 
        #If the returned statistic is larger than these critical values then for the corresponding significance level,
        #the null hypothesis that the data come from the chosen distribution can be rejected.
    
    for i in range (data.shape[1]):
        print(scipy.stats.anderson(namespace['resid_y%d' %(i+1)], dist='norm'))


#%% MS testing and Auxilliary Regressions Function reduce - Use Lagrange Multiplier test to test a set of linear restrictions

def MS_testing(data, v, trend, lag, var_cov, fit, adj_fit, scaled = False, cheby = False):
    #Making a DataFrame collecting all data needed for MS testing
    T = size(data,0)
    MS_df = data.iloc[lag:,:]
    namespace = globals()
    
    
    for i in range (data.shape[1]):
        MS_df.rename(columns={MS_df.columns[i] : 'y'+str(i+1)}, inplace = True)
        MS_df['hat_y'+str(i+1)] = fit['hat_y%d' %(i+1)]
        MS_df['hathat_y'+str(i+1)] = adj_fit['hathat_y%d' %(i+1)]
        MS_df['resid_y'+str(i+1)] = fit['resid_y%d' %(i+1)]
        MS_df['Spanos_resid_y'+str(i+1)] = fit['Spanos_resid_y%d' %(i+1)]
        MS_df['hat_volatility_y'+str(i+1)] = np.sqrt(var_cov['Var_y%d' %(i+1)])
    
    MS_df['t'] = t_make(lag+1, T) #ordinary time
    MS_df['t_s'] = scaled_t(data)[lag:] #scaled time 
    for i in range(1, trend+4):
        MS_df['t_cheby1^'+str(i)] = np.asarray(Chebyshev_poly(scaled_t(data), trend+3).iloc[lag:,i]) #orthogonal time polynomials
    
    #MS_df.set_index('t') 
    
    
    # Residuals and squared residuals with ordinary fitted value like hat_y1
    for i in range (data.shape[1]):
        namespace['resid_y%d' %(i+1)] = np.asarray(MS_df['resid_y%d' %(i+1)])
        
    for i in range (data.shape[1]):
        namespace['s_resid_y%d' %(i+1)] = np.asarray(MS_df['Spanos_resid_y%d' %(i+1)]**2)
    
    
    
    # Unrestrcited  and restricted Models - Residuals
    for i in range (data.shape[1]):
    
        namespace['Xu%d' %(i+1)] = np.c_[np.ones(T-lag)]
        namespace['Xu%d' %(i+1)] = pd.DataFrame(namespace['Xu%d' %(i+1)], columns=['constant'])
        
        for j in range (data.shape[1]):
            
            for s in range(1, lag+1):
                namespace['Xu%d' %(i+1)]['L'+str(s)+'.y'+str(j+1)] = np.asarray(MS_df['y'+str(j+1)].shift(s))
        
            for s in range(1,lag+1):
                namespace['Xu%d' %(i+1)]['L'+str(s)+'.y'+str(j+1)+'^2'] = np.asarray(MS_df['y'+str(j+1)].shift(s)**2)
        
        for s in range(1,3):
            namespace['Xu%d' %(i+1)]['L'+str(s)+'.resid_y'+str(i+1)] = np.asarray(MS_df['resid_y'+str(i+1)].shift(s))
        
        for r in range(1, trend+1):
            if scaled == False and cheby == False:
                namespace['Xu%d' %(i+1)]['t'+str(r)] = np.asarray(MS_df['t']**(r))

            elif scaled == True and cheby == False:      
                namespace['Xu%d' %(i+1)]['t'+str(r)] = np.asarray(MS_df['t_s']**(r))
        
            elif scaled == True and cheby == True:     
                namespace['Xu%d' %(i+1)]['t'+str(r)] = np.asarray(MS_df['t_cheby1^'+str(r)])
      
        for e in range(trend+1, trend+4):
            if scaled == False and cheby == False:
                namespace['Xu%d' %(i+1)]['t'+str(e)] = np.asarray(MS_df['t']**(e))

            elif scaled == True and cheby == False:      
                namespace['Xu%d' %(i+1)]['t'+str(e)] = np.asarray(MS_df['t_s']**(e))
            
            elif scaled == True and cheby == True:     
                namespace['Xu%d' %(i+1)]['t'+str(e)] = np.asarray(MS_df['t_cheby1^'+str(e)])
      
        #namespace['Xu%d' %(i+1)] = X
    
    # Restricted models
    ## Linearity r2 
    for i in range (data.shape[1]):
    
        namespace['Xu%d_r2' %(i+1)] = np.c_[np.ones(T-lag)]
        namespace['Xu%d_r2' %(i+1)] = pd.DataFrame(namespace['Xu%d_r2' %(i+1)], columns=['constant'])
        
        for j in range (data.shape[1]):
            
            for s in range(1, lag+1):
                namespace['Xu%d_r2' %(i+1)]['L'+str(s)+'.y'+str(j+1)] = np.asarray(MS_df['y'+str(j+1)].shift(s))
        
            #for s in range(1,lag+1):
                #namespace['Xu%d_r2' %(i+1)]['L'+str(s)+'.y'+str(j+1)+'^2'] = np.asarray(MS_df['y'+str(j+1)].shift(s)**2)
        
        for s in range(1,3):
            namespace['Xu%d_r2' %(i+1)]['L'+str(s)+'.resid_y'+str(i+1)] = np.asarray(MS_df['resid_y'+str(i+1)].shift(s))
        
        for r in range(1, trend+1):
            if scaled == False and cheby == False:
                namespace['Xu%d_r2' %(i+1)]['t'+str(r)] = np.asarray(MS_df['t']**(r))

            elif scaled == True and cheby == False:      
                namespace['Xu%d_r2' %(i+1)]['t'+str(r)] = np.asarray(MS_df['t_s']**(r))
        
            elif scaled == True and cheby == True:     
                namespace['Xu%d_r2' %(i+1)]['t'+str(r)] = np.asarray(MS_df['t_cheby1^'+str(r)])
      
        for e in range(trend+1, trend+4):
            if scaled == False and cheby == False:
                namespace['Xu%d_r2' %(i+1)]['t'+str(e)] = np.asarray(MS_df['t']**(e))

            elif scaled == True and cheby == False:      
                namespace['Xu%d_r2' %(i+1)]['t'+str(e)] = np.asarray(MS_df['t_s']**(e))
            
            elif scaled == True and cheby == True:     
                namespace['Xu%d_r2' %(i+1)]['t'+str(e)] = np.asarray(MS_df['t_cheby1^'+str(e)])
                
        #namespace['Xu%d_r2' %(i+1)] = X
    
    
    ## Markov r4
    for i in range (data.shape[1]):
    
        namespace['Xu%d_r4' %(i+1)] = np.c_[np.ones(T-lag)]
        namespace['Xu%d_r4' %(i+1)] = pd.DataFrame(namespace['Xu%d_r4' %(i+1)], columns=['constant'])
        
        for j in range (data.shape[1]):
            
            for s in range(1, lag+1):
                namespace['Xu%d_r4' %(i+1)]['L'+str(s)+'.y'+str(j+1)] = np.asarray(MS_df['y'+str(j+1)].shift(s))
        
            for s in range(1,lag+1):
                namespace['Xu%d_r4' %(i+1)]['L'+str(s)+'.y'+str(j+1)+'^2'] = np.asarray(MS_df['y'+str(j+1)].shift(s)**2)
        
        #for s in range(1,3):
            #X['L'+str(s)+'.resid_y'+str(i+1)] = np.asarray(MS_df['resid_y'+str(i+1)].shift(s))
        
        for r in range(1, trend+1):
            if scaled == False and cheby == False:
                namespace['Xu%d_r4' %(i+1)]['t'+str(r)] = np.asarray(MS_df['t']**(r))

            elif scaled == True and cheby == False:      
                namespace['Xu%d_r4' %(i+1)]['t'+str(r)] = np.asarray(MS_df['t_s']**(r))
        
            elif scaled == True and cheby == True:     
                namespace['Xu%d_r4' %(i+1)]['t'+str(r)] = np.asarray(MS_df['t_cheby1^'+str(r)])
      
        for e in range(trend+1, trend+4):
            if scaled == False and cheby == False:
                namespace['Xu%d_r4' %(i+1)]['t'+str(e)] = np.asarray(MS_df['t']**(e))

            elif scaled == True and cheby == False:      
                namespace['Xu%d_r4' %(i+1)]['t'+str(e)] = np.asarray(MS_df['t_s']**(e))
            
            elif scaled == True and cheby == True:     
                namespace['Xu%d_r4' %(i+1)]['t'+str(e)] = np.asarray(MS_df['t_cheby1^'+str(e)])
                
        #namespace['Xu%d_r4' %(i+1)] = X
    
    ##1st moment t-invariance r5
    for i in range (data.shape[1]):
    
        namespace['Xu%d_r5' %(i+1)] = np.c_[np.ones(T-lag)]
        namespace['Xu%d_r5' %(i+1)] = pd.DataFrame(namespace['Xu%d_r4' %(i+1)], columns=['constant'])
        
        for j in range (data.shape[1]):
            
            for s in range(1, lag+1):
                namespace['Xu%d_r5' %(i+1)]['L'+str(s)+'.y'+str(j+1)] = np.asarray(MS_df['y'+str(j+1)].shift(s))
        
            for s in range(1,lag+1):
                namespace['Xu%d_r5' %(i+1)]['L'+str(s)+'.y'+str(j+1)+'^2'] = np.asarray(MS_df['y'+str(j+1)].shift(s)**2)
        
        for s in range(1,3):
            namespace['Xu%d_r5' %(i+1)]['L'+str(s)+'.resid_y'+str(i+1)] = np.asarray(MS_df['resid_y'+str(i+1)].shift(s))
        
        for r in range(1, trend+1):
            if scaled == False and cheby == False:
                namespace['Xu%d_r5' %(i+1)]['t'+str(r)] = np.asarray(MS_df['t']**(r))

            elif scaled == True and cheby == False:      
                namespace['Xu%d_r5' %(i+1)]['t'+str(r)] = np.asarray(MS_df['t_s']**(r))
        
            elif scaled == True and cheby == True:     
                namespace['Xu%d_r5' %(i+1)]['t'+str(r)] = np.asarray(MS_df['t_cheby1^'+str(r)])
      
        # for e in range(trend+1, trend+4):
        #     if scaled == False and cheby == False:
        #         namespace['Xu%d_r5' %(i+1)]['t'+str(e)] = np.asarray(MS_df['t']**(e))

        #     elif scaled == True and cheby == False:      
        #         namespace['Xu%d_r5' %(i+1)]['t'+str(e)] = np.asarray(MS_df['t_s']**(e))
            
        #     elif scaled == True and cheby == True:     
        #         namespace['Xu%d_r5' %(i+1)]['t'+str(e)] = np.asarray(MS_df['t_cheby1^'+str(e)])
                
        #namespace['Xu%d_r5' %(i+1)] = X
        
    
    # Unrestrcited  and restricted Model - Squared Residuals
    for i in range (data.shape[1]):
    
        namespace['Xs%d' %(i+1)] = np.c_[np.ones(T-lag)]
        namespace['Xs%d' %(i+1)] = pd.DataFrame(namespace['Xs%d' %(i+1)], columns=['constant'])
        
        namespace['Xs%d' %(i+1)]['vol_y'+str(i+1)+'^3'] = np.asarray(MS_df['hat_volatility_y'+str(i+1)]**3)
        
        for s in range(1,3):
            namespace['Xs%d' %(i+1)]['L'+str(s)+'.resid_y'+str(i+1)+'^2'] = np.asarray(MS_df['resid_y'+str(i+1)].shift(s)**2)
        
        for r in range(1, trend+1):
            if scaled == False and cheby == False:
                namespace['Xs%d' %(i+1)]['t'+str(r)] = np.asarray(MS_df['t']**(r))

            elif scaled == True and cheby == False:      
                namespace['Xs%d' %(i+1)]['t'+str(r)] = np.asarray(MS_df['t_s']**(r))
        
            elif scaled == True and cheby == True:     
                namespace['Xs%d' %(i+1)]['t'+str(r)] = np.asarray(MS_df['t_cheby1^'+str(r)])
      
        for e in range(trend+1, trend+4):
            if scaled == False and cheby == False:
                namespace['Xs%d' %(i+1)]['t'+str(e)] = np.asarray(MS_df['t']**(e))

            elif scaled == True and cheby == False:      
                namespace['Xs%d' %(i+1)]['t'+str(e)] = np.asarray(MS_df['t_s']**(e))
            
            elif scaled == True and cheby == True:     
                namespace['Xs%d' %(i+1)]['t'+str(e)] = np.asarray(MS_df['t_cheby1^'+str(e)])
                
        #namespace['Xs%d' %(i+1)] = X
    
    # Restricted models
    ## Second Order Dependence r3
    for i in range (data.shape[1]):
    
        namespace['Xs%d_r3' %(i+1)] = np.c_[np.ones(T-lag)]
        namespace['Xs%d_r3' %(i+1)] = pd.DataFrame(namespace['Xs%d_r3' %(i+1)], columns=['constant'])
        
        namespace['Xs%d_r3' %(i+1)]['vol_y'+str(i+1)+'^3'] = np.asarray(MS_df['hat_volatility_y'+str(i+1)]**3)
        
        #for s in range(1,3):
         #   namespace['Xs%d' %(i+1)]['L'+str(s)+'.resid_y'+str(i+1)+'^2'] = np.asarray(MS_df['resid_y'+str(i+1)].shift(s)**2)
        
        for r in range(1, trend+1):
            if scaled == False and cheby == False:
                namespace['Xs%d_r3' %(i+1)]['t'+str(r)] = np.asarray(MS_df['t']**(r))

            elif scaled == True and cheby == False:      
                namespace['Xs%d_r3' %(i+1)]['t'+str(r)] = np.asarray(MS_df['t_s']**(r))
        
            elif scaled == True and cheby == True:     
                namespace['Xs%d_r3' %(i+1)]['t'+str(r)] = np.asarray(MS_df['t_cheby1^'+str(r)])
      
        for e in range(trend+1, trend+4):
            if scaled == False and cheby == False:
                namespace['Xs%d_r3' %(i+1)]['t'+str(e)] = np.asarray(MS_df['t']**(e))

            elif scaled == True and cheby == False:      
                namespace['Xs%d_r3' %(i+1)]['t'+str(e)] = np.asarray(MS_df['t_s']**(e))
            
            elif scaled == True and cheby == True:     
                namespace['Xs%d_r3' %(i+1)]['t'+str(e)] = np.asarray(MS_df['t_cheby1^'+str(e)])
                
        #namespace['Xs%d_r3' %(i+1)] = X
        
    ## Homoskedasticity r3_1
    for i in range (data.shape[1]):
    
        namespace['Xs%d_r3.1' %(i+1)] = np.c_[np.ones(T-lag)]
        namespace['Xs%d_r3.1' %(i+1)] = pd.DataFrame(namespace['Xs%d_r3.1' %(i+1)], columns=['constant'])
        
        #namespace['Xs%d_r3.1' %(i+1)]['vol_y'+str(i+1)+'^3'] = np.asarray(MS_df['hat_volatility_y'+str(i+1)]**3)
        
        for s in range(1,3):
            namespace['Xs%d_r3.1' %(i+1)]['L'+str(s)+'.resid_y'+str(i+1)+'^2'] = np.asarray(MS_df['resid_y'+str(i+1)].shift(s)**2)
        
        for r in range(1, trend+1):
            if scaled == False and cheby == False:
                namespace['Xs%d_r3.1' %(i+1)]['t'+str(r)] = np.asarray(MS_df['t']**(r))

            elif scaled == True and cheby == False:      
                namespace['Xs%d_r3.1' %(i+1)]['t'+str(r)] = np.asarray(MS_df['t_s']**(r))
        
            elif scaled == True and cheby == True:     
                namespace['Xs%d_r3.1' %(i+1)]['t'+str(r)] = np.asarray(MS_df['t_cheby1^'+str(r)])
      
        for e in range(trend+1, trend+4):
            if scaled == False and cheby == False:
                namespace['Xs%d_r3.1' %(i+1)]['t'+str(e)] = np.asarray(MS_df['t']**(e))

            elif scaled == True and cheby == False:      
                namespace['Xs%d_r3.1' %(i+1)]['t'+str(e)] = np.asarray(MS_df['t_s']**(e))
            
            elif scaled == True and cheby == True:     
                namespace['Xs%d_r3.1' %(i+1)]['t'+str(e)] = np.asarray(MS_df['t_cheby1^'+str(e)])
                
        #namespace['Xs%d_r3.1' %(i+1)] = X
    
    
    
    ##2nd moment t-invariance r6
    for i in range (data.shape[1]):
    
        namespace['Xs%d_r6' %(i+1)] = np.c_[np.ones(T-lag)]
        namespace['Xs%d_r6' %(i+1)] = pd.DataFrame(namespace['Xs%d_r6' %(i+1)], columns=['constant'])
        
        for j in range (data.shape[1]):
            
            namespace['Xs%d_r6' %(i+1)]['vol_y'+str(i+1)+'^3'] = np.asarray(MS_df['hat_volatility_y'+str(i+1)]**3)
        
        for s in range(1,3):
            namespace['Xs%d_r6' %(i+1)]['L'+str(s)+'.resid_y'+str(i+1)+'^2'] = np.asarray(MS_df['resid_y'+str(i+1)].shift(s)**2)
        
        for r in range(1, trend+1):
            if scaled == False and cheby == False:
                namespace['Xs%d_r6' %(i+1)]['t'+str(r)] = np.asarray(MS_df['t']**(r))

            elif scaled == True and cheby == False:      
                namespace['Xs%d_r6' %(i+1)]['t'+str(r)] = np.asarray(MS_df['t_s']**(r))
        
            elif scaled == True and cheby == True:     
                namespace['Xs%d_r6' %(i+1)]['t'+str(r)] = np.asarray(MS_df['t_cheby1^'+str(r)])
      
        # for e in range(trend+1, trend+4):
        #     if scaled == False and cheby == False:
        #         namespace['Xs%d_r6' %(i+1)]['t'+str(e)] = np.asarray(MS_df['t']**(e))

        #     elif scaled == True and cheby == False:      
        #         namespace['Xs%d_r6' %(i+1)]['t'+str(e)] = np.asarray(MS_df['t_s']**(e))
            
        #     elif scaled == True and cheby == True:     
        #         namespace['Xs%d_r6' %(i+1)]['t'+str(e)] = np.asarray(MS_df['t_cheby1^'+str(e)])
                
        #namespace['Xs%d_r6' %(i+1)] = X
    
    
    # MS Auxiliary Regressions 
    ## Residuals
    for i in range (data.shape[1]):
        # Note the difference in argument order
        namespace['Modelu_y%d' %(i+1)] = sm.OLS(namespace['resid_y%d' %(i+1)][lag:], namespace['Xu%d' %(i+1)].dropna()).fit()
        namespace['Modelu_y%d_r2' %(i+1)] = sm.OLS(namespace['resid_y%d' %(i+1)][lag:], namespace['Xu%d_r2' %(i+1)].dropna()).fit()
        namespace['Modelu_y%d_r4' %(i+1)] = sm.OLS(namespace['resid_y%d' %(i+1)][lag:], namespace['Xu%d_r4' %(i+1)].dropna()).fit()
        namespace['Modelu_y%d_r5' %(i+1)] = sm.OLS(namespace['resid_y%d' %(i+1)][lag:], namespace['Xu%d_r5' %(i+1)].dropna()).fit()
        #predictions = model.predict(X) # make the predictions by the model
        
    ## Squared Residuals
    for i in range (data.shape[1]):
        # Note the difference in argument order
        namespace['Models_y%d' %(i+1)] = sm.OLS(namespace['s_resid_y%d' %(i+1)][2:], namespace['Xs%d' %(i+1)].dropna()).fit()
        namespace['Models_y%d_r3' %(i+1)] = sm.OLS(namespace['s_resid_y%d' %(i+1)][2:]**2, namespace['Xs%d_r3' %(i+1)][2:]).fit()
        namespace['Models_y%d_r3.1' %(i+1)] = sm.OLS(namespace['s_resid_y%d' %(i+1)][2:]**2, namespace['Xs%d_r3.1' %(i+1)].dropna()).fit()
        namespace['Models_y%d_r6' %(i+1)] = sm.OLS(namespace['s_resid_y%d' %(i+1)][2:]**2, namespace['Xs%d_r6' %(i+1)].dropna()).fit()
        #predictions = model.predict(X) # make the predictions by the model
    
    
    
    
    # Print out the statistics
    for i in range (data.shape[1]):
    
        #print(namespace['Model_y%d' %(i+1)].summary())
        fig_reg(namespace['Modelu_y%d' %(i+1)])
        
        #print(namespace['Model_y%d_r2' %(i+1)].summary())
        fig_reg(namespace['Modelu_y%d_r2' %(i+1)])
        
        #print(namespace['Model_y%d_r4' %(i+1)].summary())
        fig_reg(namespace['Modelu_y%d_r4' %(i+1)])
        
        #print(namespace['Model_y%d_r5' %(i+1)].summary())
        fig_reg(namespace['Modelu_y%d_r5' %(i+1)])
        
        #print(namespace['Model_y%d' %(i+1)].summary())
        fig_reg(namespace['Models_y%d' %(i+1)])
        
        #print(namespace['Model_y%d_r3' %(i+1)].summary())
        fig_reg(namespace['Models_y%d_r3' %(i+1)])
        
        #print(namespace['Model_y%d_r3.1' %(i+1)].summary())
        fig_reg(namespace['Models_y%d_r3.1' %(i+1)])
        
        #print(namespace['Model_y%d_r6' %(i+1)].summary())
        fig_reg(namespace['Models_y%d_r6' %(i+1)])
    
    
    # MS testing report 
    for i in range (data.shape[1]):
        print('equation: y'+str(i+1))
        print('H0:', 'X2_value', 'p_value', 'df_diff')
        
        print('r2: ', namespace['Modelu_y%d' %(i+1)].compare_lm_test(namespace['Modelu_y%d_r2' %(i+1)]))
        print('r4: ', namespace['Modelu_y%d' %(i+1)].compare_lm_test(namespace['Modelu_y%d_r4' %(i+1)]))
        print('r5: ', namespace['Modelu_y%d' %(i+1)].compare_lm_test(namespace['Modelu_y%d_r5' %(i+1)]))
        
        print('r3: ', namespace['Models_y%d' %(i+1)].compare_lm_test(namespace['Models_y%d_r3' %(i+1)]))
        print('r3.1: ', namespace['Models_y%d' %(i+1)].compare_lm_test(namespace['Models_y%d_r3.1' %(i+1)]))
        print('r6:   ', namespace['Models_y%d' %(i+1)].compare_lm_test(namespace['Models_y%d_r6' %(i+1)]))
    
        #if  namespace['Modelu_y%d' %(i+1)].compare_f_test(namespace['Modelu_y%d_r2' %(i+1)])[1] :
            
        
        #(Models_y1.rsquared - Models_y1_r3.rsquared) / 
            
            
    ## Anderson - Darling Normality Test 
        #Anderson-Darling test for data coming from a particular distribution. 
        #The Anderson-Darling tests the null hypothesis that a sample is drawn from a population that follows a particular distribution.
        #For the Anderson-Darling test, the critical values depend on which distribution is being tested against.
        #This function works for normal, exponential, logistic, or Gumbel (Extreme Value Type I) distributions. 
        #If the returned statistic is larger than these critical values then for the corresponding significance level,
        #the null hypothesis that the data come from the chosen distribution can be rejected.
    
    for i in range (data.shape[1]):
        print(scipy.stats.anderson(namespace['resid_y%d' %(i+1)], dist='norm'))

